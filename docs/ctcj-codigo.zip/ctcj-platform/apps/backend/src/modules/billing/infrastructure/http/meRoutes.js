import { Router } from 'express';

import { requireAuth } from '../../../identity/infrastructure/http/middleware/requireAuth.js';

/** @param {ReturnType<import('./meController.js').createMeController>} controller */
export function createMeRoutes(controller) {
  const router = Router();

  router.get('/memberships', requireAuth, controller.getMyPlayerMemberships);
  router.get('/invoices', requireAuth, controller.getMyInvoices);

  return router;
}
