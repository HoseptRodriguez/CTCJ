/**
 * Safe defaults so buildClinicalContainer() still works standalone (e.g. in
 * tests) without requiring the cross-module wiring app.js normally
 * supplies. Mirrors every other module's null-object defaults exactly.
 */
export function createNullPlayerEligibilityProvider() {
  return {
    // Fails closed -- never treats anyone as eligible when the module isn't wired.
    async isEligiblePlayer() {
      return false;
    },
  };
}

export function createNullPractitionerEligibilityProvider() {
  return {
    // Fails closed -- never treats anyone as eligible when the module isn't wired.
    async getPractitionerEligibility() {
      return { eligible: false, discipline: null };
    },
  };
}

export function createNullPlayerDirectoryProvider() {
  return {
    // Fails open (empty map) -- this is display enrichment, not an authz gate.
    async getPlayerSummaries() {
      return new Map();
    },
  };
}

/** Standalone/test default: collects reads in memory (never touches the DB). */
export function createInMemoryClinicalAuditLog() {
  const reads = [];
  return {
    reads,
    async recordNoteReads(read) {
      reads.push(read);
    },
  };
}

export function createNullHealthAuthorizationProvider() {
  return {
    // Fails closed -- no health data is recorded without a known authorization.
    async hasHealthAuthorization() {
      return false;
    },
  };
}
