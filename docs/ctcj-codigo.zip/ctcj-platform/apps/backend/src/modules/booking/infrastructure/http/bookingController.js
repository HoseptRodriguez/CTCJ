import { ROLE_CODES } from '@ctcj/shared';

import { mapBookingError } from './errorMapping.js';

const STAFF_ROLES = [ROLE_CODES.ADMINISTRADOR, ROLE_CODES.RECEPCION];

function isStaff(roles = []) {
  return roles.some((role) => STAFF_ROLES.includes(role));
}

function asyncHandler(fn) {
  return (req, res, next) => {
    fn(req, res, next).catch((err) => next(mapBookingError(err)));
  };
}

/** @param {ReturnType<import('../compositionRoot.js').buildBookingContainer>} container */
export function createBookingController(container) {
  const listCourts = asyncHandler(async (req, res) => {
    const courts = await container.listCourts();
    res.status(200).json({ courts });
  });

  const getSchedule = asyncHandler(async (req, res) => {
    const viewer = { userId: req.user?.id ?? null, isStaff: isStaff(req.user?.roles) };
    const result = await container.getSchedule({ date: req.query.date, viewer });
    res.status(200).json(result);
  });

  const hold = asyncHandler(async (req, res) => {
    const result = await container.createHold({
      courtId: req.body.courtId,
      periodStart: req.body.start,
      periodEnd: req.body.end,
      holderUserId: req.body.holderUserId ?? req.user.id,
      createdByUserId: req.user.id,
    });
    res.status(201).json(result);
  });

  const confirm = asyncHandler(async (req, res) => {
    const result = await container.confirmReservation({
      reservationId: req.body.reservationId,
      userId: req.user.id,
      isStaff: isStaff(req.user.roles),
    });
    res.status(200).json(result);
  });

  const addSecondHour = asyncHandler(async (req, res) => {
    const result = await container.addSecondHour({
      reservationId: req.params.id,
      userId: req.user.id,
      isStaff: isStaff(req.user.roles),
    });
    res.status(200).json(result);
  });

  const removeSecondHour = asyncHandler(async (req, res) => {
    const result = await container.removeSecondHour({
      reservationId: req.params.id,
      userId: req.user.id,
      isStaff: isStaff(req.user.roles),
    });
    res.status(200).json(result);
  });

  const getSecondHourPolicy = asyncHandler(async (req, res) => {
    res.status(200).json(await container.getSecondHourPolicy());
  });

  const setSecondHourPolicy = asyncHandler(async (req, res) => {
    const result = await container.setSecondHourPolicy({
      enabled: req.body.enabled,
      updatedByUserId: req.user.id,
    });
    res.status(200).json(result);
  });

  const cancel = asyncHandler(async (req, res) => {
    const result = await container.cancelReservation({
      reservationId: req.params.id,
      userId: req.user.id,
      isStaff: isStaff(req.user.roles),
    });
    res.status(200).json(result);
  });

  const setCourtPrice = asyncHandler(async (req, res) => {
    const result = await container.setCourtPrice({
      courtId: req.params.id,
      priceCop: req.body.priceCop,
      actorUserId: req.user.id,
      actorRoles: req.user.roles ?? [],
    });
    res.status(200).json(result);
  });

  const getCourtPriceHistory = asyncHandler(async (req, res) => {
    res.status(200).json(await container.getCourtPriceHistory({ courtId: req.params.id }));
  });

  const recordPayment = asyncHandler(async (req, res) => {
    const result = await container.recordPayment({
      reservationId: req.params.id,
      method: req.body.method,
      notes: req.body.notes,
      recordedBy: req.user.id,
    });
    res.status(201).json(result);
  });

  const listPayments = asyncHandler(async (req, res) => {
    const result = await container.listPaymentsByDateRange({
      from: req.query.from,
      to: req.query.to,
    });
    res.status(200).json(result);
  });

  const getMonthlyRevenue = asyncHandler(async (req, res) => {
    const result = await container.getMonthlyRevenue({ months: req.query.months });
    res.status(200).json(result);
  });

  const getMyTrainingFrequency = asyncHandler(async (req, res) => {
    const days = req.query.days ? Number(req.query.days) : undefined;
    const result = await container.getMyTrainingFrequency({ playerId: req.user.id, days });
    res.status(200).json(result);
  });

  const getMyReservations = asyncHandler(async (req, res) => {
    const result = await container.getMyReservations({ userId: req.user.id });
    res.status(200).json(result);
  });

  // Staff: a player's reservations, for their file in the directory.
  const getPlayerReservations = asyncHandler(async (req, res) => {
    res.status(200).json(await container.getMyReservations({ userId: req.params.id }));
  });

  const getOverduePolicy = asyncHandler(async (req, res) => {
    const result = await container.getOverdueBookingPolicy();
    res.status(200).json(result);
  });

  const setOverduePolicy = asyncHandler(async (req, res) => {
    const result = await container.setOverdueBookingPolicy({
      enabled: req.body.enabled,
      updatedByUserId: req.user.id,
    });
    res.status(200).json(result);
  });

  const getHoldDuration = asyncHandler(async (req, res) => {
    res.status(200).json(await container.getHoldDurationPolicy());
  });

  const setHoldDuration = asyncHandler(async (req, res) => {
    const result = await container.setHoldDurationPolicy({
      minutes: req.body.minutes,
      updatedByUserId: req.user.id,
    });
    res.status(200).json(result);
  });

  return {
    listCourts,
    getSchedule,
    hold,
    confirm,
    cancel,
    addSecondHour,
    removeSecondHour,
    getSecondHourPolicy,
    setSecondHourPolicy,
    setCourtPrice,
    getCourtPriceHistory,
    recordPayment,
    listPayments,
    getMonthlyRevenue,
    getMyTrainingFrequency,
    getMyReservations,
    getPlayerReservations,
    getOverduePolicy,
    setOverduePolicy,
    getHoldDuration,
    setHoldDuration,
  };
}
