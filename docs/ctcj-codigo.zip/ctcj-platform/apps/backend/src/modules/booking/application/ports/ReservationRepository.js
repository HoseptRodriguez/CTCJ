/**
 * @typedef {import('../../domain/entities/Reservation.js').Reservation} Reservation
 */

export class ReservationRepository {
  /**
   * Inserts a new HOLD reservation. Implementations must translate a
   * Postgres exclusion-constraint violation (double-booking) into
   * SlotNotAvailable -- optimistic-insert-and-catch, not check-then-insert,
   * to avoid a race under concurrency.
   * @returns {Promise<Reservation>}
   */
  async createHold(_reservation) {
    throw new Error('Not implemented');
  }

  /** @returns {Promise<Reservation|null>} */
  async findById(_id) {
    throw new Error('Not implemented');
  }

  /** Occupying (HOLD/CONFIRMED) reservations for a club's court schedule over [dayStart, dayEnd). @returns {Promise<Reservation[]>} */
  async listOccupyingByClubAndDateRange(_clubId, _dayStart, _dayEnd) {
    throw new Error('Not implemented');
  }

  /** @returns {Promise<number>} count of the holder's current HOLD/CONFIRMED reservations. */
  async countOccupyingByHolder(_holderUserId) {
    throw new Error('Not implemented');
  }

  /**
   * The holder's own reservations (any status) over [from, to) -- unlike
   * listOccupyingByClubAndDateRange (club-wide, occupying statuses only,
   * forward-looking schedule use), this covers historical ranges too, e.g.
   * "how many times did I train last week" (Goals/Achievements, Phase 2).
   * @returns {Promise<Reservation[]>}
   */
  async listByHolderAndDateRange(_holderUserId, _from, _to) {
    throw new Error('Not implemented');
  }

  /**
   * Occupying (HOLD/CONFIRMED) reservations over [from, to) where `userId`
   * is the holder OR the one who created it (a guardian booking for a
   * minor) -- the same "own booking" rule reservationPrivacy.js applies.
   * Ordered by start.
   * @returns {Promise<Reservation[]>}
   */
  async listOccupyingByParticipantAndDateRange(_userId, _from, _to) {
    throw new Error('Not implemented');
  }

  /**
   * Atomically transitions status only if the row is currently in one of
   * `fromStatuses` -- a 0 result means the row changed underneath the call
   * (e.g. the expiry job fired first), which the caller must handle.
   * @returns {Promise<number>} rows affected (0 or 1)
   */
  async transitionStatus({
    id: _id,
    fromStatuses: _fromStatuses,
    toStatus: _toStatus,
    extra: _extra,
  }) {
    throw new Error('Not implemented');
  }

  /**
   * Reservations of a court that still hold it (HOLD or CONFIRMED) and start
   * after `from` -- the ones a price change leaves at their own price.
   * @returns {Promise<number>}
   */
  async countUpcomingByCourt(_courtId, _from) {
    throw new Error('Not implemented');
  }

  /**
   * Moves the end of a HOLD (adding or removing its second hour) and sets
   * its price, in one conditional update. Throws SlotNotAvailable when the
   * database's exclusion constraint rejects the new period.
   * @param {{ id: string, periodEnd: Date, priceCop: bigint|null }} _input
   * @returns {Promise<import('../../domain/entities/Reservation.js').Reservation|null>} null if it's no longer a HOLD
   */
  async resizeHold(_input) {
    throw new Error('Not implemented');
  }
}
